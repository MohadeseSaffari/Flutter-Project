import java.util.List;

public class Teacher {
    private String firstname;
    private String lastname;
    private int NumberOfCourseProvides;
    private List <Course> CourseProvideslist;
    private List <Student> studentList;
    public void addStudent(Course course,Student newStudent){
        studentList.add(newStudent);
        newStudent.participateInCourse(course);
    }
    public void removeStudent(Student student, Course course){
        studentList.remove(student);
        student.leftTheCourse(course);
    }
    public void addScore(Student student, int score){
        student.score(score);
    }
    public void setAssignment(Course course, Assignment assignment, Teacher teacher){
        if (teacher.getCourseProvideslist().contains(course)){
            course.getAssignmentList().add(assignment);
        }
        else
            System.out.println(teacher.getFirstname() + " " + teacher.getLastname() + " doesn't teach this course.");
    }
    public void removeAssignment(Course course, Assignment assignment, Teacher teacher){
        if (teacher.getCourseProvideslist().contains(course)){
            course.getAssignmentList().remove(assignment);
        }
        else
            System.out.println(teacher.getFirstname() + " " + teacher.getLastname() + " doesn't teach this course.");
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setNumberOfCourseProvides(int numberOfCourseProvides) {
        NumberOfCourseProvides = numberOfCourseProvides;
    }

    public void setCourseProvideslist(List<Course> courseProvideslist) {
        CourseProvideslist = courseProvideslist;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }


    public int getNumberOfCourseProvides() {
        return NumberOfCourseProvides;
    }

    public List<Course> getCourseProvideslist() {
        return CourseProvideslist;
    }

    public List<Student> getStudentList() {
        return studentList;
    }
}
