import java.util.ArrayList;
import java.util.List;

public class Student {
    private String name;
    int score = 0;
    private int id;
    private int NumberOfSubject;
    private int NumberOfCredits;
    private int NumberOfCourses;
    private List <Course> courseList = new ArrayList<>();
    private double TotalAverage;
    private double CurrentAverage;
    Student(String name, int id){
        this.name = name;
        this.id = id;
    }
    public void participateInCourse(Course course){
        courseList.add(course);
        NumberOfCourses++;
        NumberOfCredits += course.getNumberOfCredit();
    }
    public void leftTheCourse(Course course){
        courseList.remove(course);
        NumberOfCourses--;
        NumberOfCredits -= course.getNumberOfCredit();
    }

    public void printListOfCourses(){
        for (Course course : courseList) {
            System.out.println(course);
        }
    }
    public void printTotalAverage(Student student){
        int sum = 0;
        for (int i = 0; i < NumberOfCourses; i++){
            sum+=student.score;
        }
        TotalAverage = (double) sum /NumberOfCourses;
        System.out.println(TotalAverage);
    }
    public void printNumberOfCredits(){
        System.out.println(NumberOfCredits);
    }
    public void score(int score){
        score++;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumberOfCredits(int numberOfCredits) {
        NumberOfCredits = numberOfCredits;
    }

    public void setNumberOfCourses(int numberOfCourses) {
        NumberOfCourses = numberOfCourses;
    }

    public void setCourseList(List<Course> courseList) {
        this.courseList = courseList;
    }

    public void setCurrentAverage(double currentAverage) {
        CurrentAverage = currentAverage;
    }

    public void setTotalAverage(double totalAverage) {
        TotalAverage = totalAverage;
    }

    public void setNumberOfSubject(int numberOfSubject) {
        NumberOfSubject = numberOfSubject;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getNumberOfCredits() {
        return NumberOfCredits;
    }

    public int getNumberOfCourses() {
        return NumberOfCourses;
    }

    public int getNumberOfSubject() {
        return NumberOfSubject;
    }

    public List<Course> getCourseList() {
        return courseList;
    }

    public double getCurrentAverage() {
        return CurrentAverage;
    }

    public double getTotalAverage() {
        return TotalAverage;
    }
}
